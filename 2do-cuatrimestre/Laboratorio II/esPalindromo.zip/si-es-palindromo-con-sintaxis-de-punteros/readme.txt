Se hace build con:
> gcc main.c src/string.min.h/string.c src/palindromo.h/palindromo.c

Se corre con (PowerShell): 
	> ./a.exe
O desde cmd con: 
	> a.exe