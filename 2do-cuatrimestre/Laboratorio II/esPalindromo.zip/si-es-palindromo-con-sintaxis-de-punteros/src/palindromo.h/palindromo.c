#include <stdio.h>
#include "palindromo.h"
void obtenerPalabra(const char a[], char salida[], int *comienzo)
{
    /**
     * @param const char a[] recibe un vector de chars
     * @param char salida[] almacena la palabra
     * @param int *comienzo es el punto de partida en la cuál la función comienza a leer
     */
    a = a+*comienzo; // Aplico el offset
    while( *a && *a != ' ' )
    {
        *salida = *a;
        salida++;
        a++;
        *comienzo++;
    }
}