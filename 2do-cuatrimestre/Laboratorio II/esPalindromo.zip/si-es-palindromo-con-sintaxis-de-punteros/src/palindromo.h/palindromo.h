#define MAX_CANT_CARACTERES 256
#define MAX_CANT_PALINDROMOS 64
void obtenerPalabra(const char a[], char salida[], int *comienzo);