#include <stdio.h>
#include "string.h"
int contarChars(char a[])
{
    int contador = 0;
    while(*a)
    {
        a++;
        if(*a == ' ')
            contador++;
    }
    return contador;
}
