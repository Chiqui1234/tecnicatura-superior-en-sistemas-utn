#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "src/palindromo.h/palindromo.h"
#include "src/string.min.h/string.h"

int main()
{
    char entrada[MAX_CANT_PALINDROMOS] = "ala martin neuquen ";
    char palindromo[MAX_CANT_CARACTERES];
    int cantPalabras = contarChars(entrada);
    int i = 0;
    while( *(entrada+i) )
    {
        obtenerPalabra(entrada, palindromo, &i);
        
        printf("%s, i = %d\n", palindromo, i);       
    }
    
}