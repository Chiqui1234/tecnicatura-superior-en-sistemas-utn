/* cyan and boldCyan outputs yellow IN SOME Linux terminals
   If that happens to you, note yellow and boldYellow are darker than normal.
   darkBlue and darkBlueBold only work in Linux :O
   Sorry for the inconvenience. */
void c_reset();
void c_red();
void c_boldRed();
void c_green();
void c_boldGreen();
void c_yellow();
void c_boldYellow();
void c_blue();
void c_boldBlue();
void c_magenta();
void c_boldMagenta();
void c_cyan();
void c_boldCyan();
void c_silver();
void c_boldSilver();
void c_darkBlue();
void c_boldDarkBlue();