#include <stdio.h>
#include <stdlib.h>
#include "colors.h"

typedef struct
{
    char nombre[20];
    unsigned int dni;
} ST_INVITADO;

typedef enum 
{
    FALSE=0,
    TRUE
} BOOL;

BOOL pre_load(ST_INVITADO *invitado);
void save(FILE *stream, ST_INVITADO invitado);
void print(FILE *stream, int i);