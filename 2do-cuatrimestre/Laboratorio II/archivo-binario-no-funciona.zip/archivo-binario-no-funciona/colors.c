#include <stdio.h>
void c_reset()
{
  printf("\033");
}
void c_red()
{
  printf("\033[0;31m");
}
void c_boldRed()
{
  printf("\033[1;31m");
}
void c_green()
{
  printf("\033[0;32m");
}
void c_boldGreen()
{
  printf("\033[1;32m");
}
void c_yellow()
{
  printf("\033[0;33m");
}
void c_boldYellow()
{
  printf("\033[1;33m");
}
void c_blue()
{
  printf("\033[0;34m");
}
void c_boldBlue()
{
  printf("\033[1;34m");
}
void c_magenta()
{
  printf("\033[0;35m");
}
void c_boldMagenta()
{
  printf("\033[1;35m");
}
void c_cyan()
{
  printf("\033[0;36m");
}
void c_boldCyan()
{
  printf("\033[1;36m");
}
void c_silver()
{
  printf("\033[0;37m");
}
void c_boldSilver()
{
  printf("\033[1;37m");
}
void c_darkBlue()
{
  printf("\033[0;38m");
}
void c_boldDarkBlue()
{
  printf("\033[1;38m");
}
