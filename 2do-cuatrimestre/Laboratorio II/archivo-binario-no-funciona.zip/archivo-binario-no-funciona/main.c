#include "src/funciones.h"

int main()
{
    ST_INVITADO invitado;
    FILE *binary = NULL;
    BOOL status;
    int i = 0; // Este contador lo sumo dentro de la función pre_load. Sirve para controlar el while() que imprime las personas agregadas

    if( (binary = fopen("binario.bin", "wb")) == NULL )
        exit(EXIT_FAILURE);

    status = pre_load(&invitado);
    save(binary, invitado);

    while( status && !feof(binary) )        // Mientras el usuario no ponga un cero cómo DNI y no llegue a EOF, el bucle sigue
    {
        status = pre_load(&invitado);   // el usuario carga datos
        save(binary, invitado);             // inmediatamente los guardo en el binario
        i++;
    }
    print(binary, i);
    
    fclose(binary);
}